﻿namespace ManageWorks.DTO
{
    public class RegisterDto
    {
        public string? Username { get; set; }
        public string? Password { get; set; }
    }
}
