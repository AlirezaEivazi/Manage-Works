﻿namespace ManageWorks.DTO
{
    public class CategoryDto
    {
        public string Name { get; set; }
    }
}