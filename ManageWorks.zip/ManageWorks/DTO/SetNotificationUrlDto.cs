﻿namespace ManageWorks.DTO
{
    public class SetNotificationUrlDto
    {
        public string Url { get; set; }
    }
}
